/*
* @file libping.c
*
* @author Andy Lindsay
*
* @copyright
* Copyright (C) Parallax, Inc. 2013. All Rights MIT Licensed.
*
* @brief Project and test harness for the ping library.
*/


#include "simpletools.h"
#include "ping.h"

int main()
{
}
